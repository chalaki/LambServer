var logger = console;
var response = {};
var conString = "postgresql://postgres:SfApps123@localhost:5432/limesurvey29";
const { Client } = require('pg');
var client;

exports.handler = async (event) => {
	logger.log("Loading Java Lambda handler of ProxyWithStream --");
	//"postgresql://postgres:SfApps123@vox.cig7k7sblhaw.ap-south-1.rds.amazonaws.com:5432/limesurvey29";	
	client = new Client(conString);
	await client.connect();

	var startTime = new Date().getMilliseconds();
	var responseJson = {};
	var surveyId = "";
	var surveyName = "";
	var supplierId = "";
	var supplierName = "";
	var sdate = "";
	var edate = "";
	var responseCode = "200";
	try {
		responseJson["statusCode"] = "400"; // assume error..overwrite later
		logger.log("-- Event received: ")
		logger.log(event);

		if (event.queryStringParameters != null) {
			var qps = event.queryStringParameters;
			if (qps["surveyId"] != null) surveyId = qps["surveyId"];
			if (qps["surveyName"] != null)
				surveyName = qps["surveyName"];
			if (qps["supplierId"] != null)
				supplierId = qps["supplierId"];
			if (qps["supplierName"] != null)
				supplierName = qps["supplierName"];
			if (qps["sdate"] != null)
				sdate = qps["sdate"];
			if (qps["edate"] != null)
				edate = qps["edate"];
		}
		logger.log("  Received event: surveyId,  surveyName, supplierId, supplierName, sdate, edate: " + surveyId
			+ ", " + surveyName + ", " + supplierId + ", " + supplierName + ", " + sdate + ", " + edate);

		var arr = [];

		surveys = await getRawDataId();
		var suprep = [];
		suprep = await getSuppliersReport(surveyId, surveyName, supplierId, supplierName, sdate, edate);
		var suppliers = [];
		suppliers = await getSuppliersData();
		logger.log(suprep.toString());


		var responseBody = {};
		responseBody.supreport = suprep;
		responseBody.suppliers = suppliers;
		responseBody.surveys = surveys;
		var stopTime = new Date().getMilliseconds();
		var elapsedTime = (stopTime - startTime) / 1000.0;
		responseBody.elapsed = elapsedTime;

		var headerJson = {};
		headerJson["x-custom-header"] = "my custom header value";
		responseJson.isBase64Encoded = false;
		responseJson.statusCode = responseCode;
		responseJson.headers = headerJson;
		responseJson.body = JSON.stringify(responseBody);
	}
	catch (pex) {
		logger.log(pex.toString());
	}
	logger.log(responseJson);
	await client.end();
	return response;
}


const getRawDataId = async function (context) {

	logger.log("---- getRawDataId");
	var rowObj = null;
	var arr = [];
	try {
		var activeSurveys = [];
		activeSurveys = await getActiveSurveyIds(context);
		logger.log('---- getRawDataId: getActiveSurveyIds() returned: ' + getActiveSurveyIds.length)
		var query = "Select surveyls_survey_id, surveyls_title from lime_surveys_languagesettings ";
		//logger.log("Query :" + query);
		//			client.query (query, (err, result) => {
		//				 if (err) logger.log("Error executing query.", err);
		//		          else {
		//		        	  result.rows.forEach (function myFunction(rowObj, index, array) {
		//			        		logger.log(rowObj);
		//							if (rowObj[2] != '' && activeSurveys.includes(rowObj.surveyls_survey_id)) arr.push(rowObj);
		//		        	  });
		//		        	  logger.log("---- getRawDataId" );
		//		        	  logger.log(arr);
		//		          }
		//			});


		const res = await client.query(query);
		res.rows.forEach(function myFunction(rowObj, index, array) {
			//logger.log(rowObj);
			if (rowObj.surveyls_survey_id != '' && activeSurveys.includes(rowObj.surveyls_survey_id)) arr.push(rowObj);
		});
		logger.log("---- done getRawDataId");
		//logger.log(arr);


	}
	catch (e) {
		logger.log(e);
	}
	return arr;
}

const getSuppliersData = async function (context) {

	logger.log("----  getSuppliersData()");
	var rowObj = {};
	var arr = [];
	try {
		var query = "Select distinct supplier_id, supplier_name from da_supplier_details ";
		logger.log("Query :" + query);
		// client.query(query, (err, result) => {
		// 	if (err) {
		// 		logger.log("Error executing query.", err);
		// 	}
		// 	else {
		// 		for (rowObj in result.rows) {
		// 			var obj = {};
		// 			obj.supplier_id = rowObj[1];
		// 			obj.supplier_name = rowObj[2];
		// 			arr.push(obj);
		// 		}
		// 	}
		// });
		const result = await client.query(query);
		//for (rowObj in result.rows) {
		result.rows.forEach(function (rowObj) {
			// var obj = {};
			// obj.supplier_id = rowObj[1];
			// obj.supplier_name = rowObj[2];
			arr.push(rowObj);
		});
	}
	catch (e) {
		logger.log(e);
	}
	return arr;
}


const getSuppliersReport = async function (context, surveyId, surveyName, supplierId, supplierName, _sdate, _edate) {

	var colName = await getColumnName(context, "AC", surveyId);
	logger.log("------getColumnName() returned-------: " + colName);

	logger.log("\r\n----------- getSupplierReport () surveyid: " + surveyId + " col name: " + colName
		+ " start date: " + _sdate + " end date: " + _edate);
	var returnJSONObj = {}; // final response {}
	var arrayOfColumns = [];
	var title = {};
	var arrayOfRows = [];
	var supRepTable = {};
	var condition2 = "";
	try {
		returnJSONObj.Status = "Failure"; // assume failure later overwrite

		arrayOfColumns = [];
		title = {};
		arrayOfRows = [];

		supRepTable = {};

		var sdate = new Date(_sdate); //new SimpleDateFormat("yyyy-MM-dd").parse(_sdate);
		var edate = new Date(_edate);//new SimpleDateFormat("yyyy-MM-dd").parse(_edate);

		var Started_Count = "0", Achieved_Count = "0", Target_Count = "0", Pending_Count = "0",
			Active_HUser_Count = "0", Total_Surveys_Done = "0";

		logger.log(sdate.toString());
		logger.log(edate.toString());
		//logger.log("edate.compareTo(dt) :" + edate.compareTo(sdate));
		for (var dt = sdate; dt <= edate;) {

			var strDate = dt.toISOString().split('T')[0];
			logger.log("date in for loop :" + strDate);

			if (strDate != null && strDate.trim().length != 0)
				condition2 = " and ls.submitdate::date <= date '" + strDate + "' ";

			var Started_AC_Count_query = "select count(*) from (select distinct split_part(ls.\"" + colName
				+ "\", '_', 2) from lime_survey_" + surveyId + " ls, da_supplier_details sd "
				+ " where ls.hybrid_userid= sd.h_uid and sd.supplier_id=" + supplierId + condition2
				+ " and ls.\"" + colName + "\" like '%\\_%' " + " and split_part(ls.\"" + colName
				+ "\", '_', 2) ~ E'^\\\\d+$' " // Postgresql ~ pattern matching operator to make sure its
				// integer
				+ " ) as foo";

			var Target_AC_Count_query = "select   count (distinct acid), supplier_id, supplier_name  from da_supplier_details where supplier_id="
				+ supplierId + " group by supplier_id, supplier_name";
			var Achieved_AC_Count_query = "SELECT supplier_id, sum(TotalQuotaInAC) as TotalQuota, sum(achieved_status) as Achieved_ACs from "
				+ "(select *, case when TotalQuotaInAC - FinishedSurveys > 0 then 0   else  1 end as achieved_status  from  "

				+ "(select sd.supplier_id, sd.acid,  sum(pb.quota) as TotalQuotaInAC  " + " from "
				+ "(select distinct ac_id_09, booth_id_14, quota  from stl_polling_booth)  pb " + "INNER JOIN "
				+ "(select distinct supplier_id, acid from da_supplier_details)  sd "
				+ "ON pb.ac_id_09= sd.acid  and sd.supplier_id=" + supplierId + " "
				+ " group by sd.acid, sd.supplier_id) sup_ac_totqota, "

				+ "(select  supplier_id as supid, split_part(ls.\"" + colName + "\", '_', 1) AS ACName, "
				+ "   CAST (split_part(ls.\"" + colName + "\", '_', 2) AS INTEGER) AS acid,       "
				+ "   count(ls.\"" + colName + "\") as FinishedSurveys from lime_survey_" + surveyId
				+ " ls, da_supplier_details sd " + "where ls.hybrid_userid= sd.h_uid and sd.supplier_id="
				+ supplierId + " " + "and ls.\"" + colName + "\" like '%\\_%' " + "and split_part(ls.\""
				+ colName + "\", '_', 2) ~ E'^\\\\d+$' " // Postgresql ~ pattern matching operator to make sure
				// its integer
				+ condition2 + "GROUP BY ls.\"" + colName + "\", sd.supplier_id) sup_ac_finished_surveys "

				+ "WHERE sup_ac_totqota.acid = sup_ac_finished_surveys.acid and supplier_id = supid  "
				+ "ORDER BY sup_ac_totqota.supplier_id, sup_ac_totqota.acid)  combined_data "
				+ "GROUP BY supplier_id";

			var ActiveHybridUsersCountQuery = "select count (distinct (h_uid))  from da_supplier_details sd, lime_survey_"
				+ surveyId + " ls  " + "where ls.hybrid_userid= sd.h_uid and sd.supplier_id=" + supplierId
				+ condition2;

			var TotalSurveysDoneQuery = "select count(*)  from da_supplier_details sd, lime_survey_" + surveyId
				+ " ls,  stl_anonymous_user_survey aus "
				+ "where ls.hybrid_userid= sd.h_uid AND ls.userid = aus.userid and aus.sid=" + surveyId
				+ " and aus.cf='Y' AND sd.supplier_id=" + supplierId + condition2;

			var rs1 = null, rs2 = null, rs3 = null, rs4 = null, rs5 = null;
			var row_obj = [];
			try {

				logger.log("Target_AC_Count_query :" + Target_AC_Count_query);
				// client.query(Target_AC_Count_query, (err, result) => {
				// 	if (err) {
				// 		logger.log("Error executing query.", err);
				// 	}
				// 	else {
				// 		for (rs2 in result.rows) {
				// 			Target_Count = rs2[1];
				// 			logger.log("Target_Count ........... " + Target_Count);
				// 			row_obj.push(Target_Count);
				// 		}
				// 	}
				// });
				var result = await client.query(Target_AC_Count_query);
				result.rows.forEach(function (rs2) {
					Target_Count = rs2.count;
					logger.log("Target_Count ........... " + Target_Count);
					row_obj.push(Target_Count);
				});


				row_obj.push(strDate);

				logger.log("Started_AC_Count_query :" + Started_AC_Count_query);
				// client.query(Target_AC_Count_query, (err, result) => {
				// 	if (err) {
				// 		logger.log("Error executing query.", err);
				// 	}
				// 	else {
				// 		for (rs1 in result.rows) {
				// 			Started_Count = rs1[1];
				// 			logger.log("Started_Count ........... " + Started_Count);
				// 			row_obj.push(Started_Count);
				// 		}
				// 	}
				// });
				const result2 = await client.query(Started_AC_Count_query);
				//for (rs1 in result2.rows) {
				result2.rows.forEach(function (rs1) {
					Started_Count = rs1.count;
					logger.log("Started_Count ........... " + Started_Count);
					row_obj.push(Started_Count);
				});

				logger.log("Achieved_AC_Count_query :" + Achieved_AC_Count_query);
				var _Achieved_Count = "0";
				var TotalQuota = "0";
				// client.query(Achieved_AC_Count_query, (err, result) => {
				// 	if (err) {
				// 		logger.log("Error executing query.", err);
				// 	}
				// 	else {
				// 		if (result.rows.count > 0) {
				// 			_Achieved_Count = rs3.getString("Achieved_ACs");
				// 			TotalQuota = rs3.getString("TotalQuota");
				// 		}
				// 		else {
				// 			_Achieved_Count = "0";
				// 		}
				// 	}
				// });
				const result3 = await client.query(Achieved_AC_Count_query);
				if (result3.rows.length > 0) {
					rs3 = result3.rows[0];
					_Achieved_Count = rs3.achieved_acs;
					TotalQuota = rs3.totalquota;
				}
				else {
					_Achieved_Count = "0";
				}

				var diff = parseInt(Achieved_Count) - parseInt(_Achieved_Count);
				Achieved_Count = _Achieved_Count;

				logger.log("Achieved_Count, TotalQuota ........... " + Achieved_Count + "   " + TotalQuota);
				row_obj.push(Achieved_Count);

				Pending_Count = (parseInt(Target_Count) - parseInt(Achieved_Count)).toString();
				logger.log("Pending_Count ........... " + Pending_Count);
				row_obj.push(Pending_Count);

				logger.log("ActiveHybridUsersCountQuery :" + ActiveHybridUsersCountQuery);


				//rs4 = stmt4.executeQuery(ActiveHybridUsersCountQuery);
				var _Active_HUser_Count = "0"; // current value
				// client.query(ActiveHybridUsersCountQuery, (err, result) => {
				// 	if (err) {
				// 		logger.log("Error executing query.", err);
				// 	}
				// 	else {
				// 		for (rs4 in result.rows) {
				// 			_Active_HUser_Count = rs4[1];
				// 		}
				// 	}
				// });
				const result4 = await client.query(ActiveHybridUsersCountQuery);
				//for (rs4 in result4.rows) {
				result4.rows.forEach(function (rs4) {
					_Active_HUser_Count = rs4.count;
				});

				logger.log("Active_HUser_Count ........... " + _Active_HUser_Count);
				row_obj.push(_Active_HUser_Count);
				diff = parseInt(_Active_HUser_Count) - parseInt(Active_HUser_Count);
				Active_HUser_Count = _Active_HUser_Count;
				if (dt == sdate)
					row_obj.push("N/A");
				else
					row_obj.push(diff);

				logger.log("TotalSurveysDoneQuery :" + TotalSurveysDoneQuery);


				//rs5 = stmt5.executeQuery(TotalSurveysDoneQuery);
				var _Total_Surveys_Done = "0"; // current value
				// client.query(TotalSurveysDoneQuery, (err, result) => {
				// 	if (err) {
				// 		logger.log("Error executing query.", err);
				// 	}
				// 	else {
				// 		for (rs5 in result.rows) {
				// 			_Total_Surveys_Done = rs5[1];
				// 		}
				// 	}
				// });
				const result5 = await client.query(TotalSurveysDoneQuery);
				//for (rs5 in result5.rows) {
				result5.rows.forEach(function (rs5) {
					_Total_Surveys_Done = rs5.count;
				});

				logger.log("Total_Surveys_Done ........... " + _Total_Surveys_Done);
				row_obj.push(TotalQuota);
				row_obj.push(_Total_Surveys_Done);
				diff = parseInt(_Total_Surveys_Done) - parseInt(Total_Surveys_Done);
				Total_Surveys_Done = _Total_Surveys_Done;
				if (dt == sdate)
					row_obj.push("N/A");
				else
					row_obj.push(diff);

				logger.log("resultset ........... " + row_obj);
				arrayOfRows.push(row_obj);
			}
			catch (e) {
				logger.log(e);
			}
			finally {
				// [rs1, rs2, rs3, rs4, rs5].forEach(function (x) {
				// 	if (x != null) {
				// 		try {
				// 			x.close();
				// 		} catch (e) {
				// 			logger.log(e);
				// 		}
				// 	}
				// });
			}

			//var ltime = dt.getTime() + 1 * 24 * 60 * 60 * 1000;
			dt.setDate(dt.getDate() + 1);
			//new java.util.Date(ltime); // increment date by one day
		} // for loop

		title = {};
		var timeStamp = (new Date()).toDateString();
		title.title = supplierName + " (" + surveyName + ") " + _sdate + " to " + _edate + " at: " + timeStamp;
		arrayOfColumns.push(title);
		var col1 = {}, col2 = {}, col3 = {},
			col4 = {}, col5 = {}, col6 = {}, col7 = {},
			col8 = {}, col9 = {};
		col1.title = "Target AC Count";
		col2.title = "Started AC Count";
		col3.title = "Achieved AC Count";
		col4.title = "Pending AC Count";
		col5.title = "Active Hybrid Users";
		col6.title = "Daily New Users";
		col7.title = "Tot. Quota";
		col8.title = "Tot. Surveys Done";
		col9.title = "New Surveys";

		arrayOfColumns.push(col1);
		arrayOfColumns.push(col2);
		arrayOfColumns.push(col3);
		arrayOfColumns.push(col4);
		arrayOfColumns.push(col5);
		arrayOfColumns.push(col6);
		arrayOfColumns.push(col7);
		arrayOfColumns.push(col8);
		arrayOfColumns.push(col9);
		supRepTable.TITLE1 = supplierName + " (" + surveyName + ") From " + _sdate + " to " + _edate
			+ " Report time: " + timeStamp;
		supRepTable.COLUMNS = arrayOfColumns;
		supRepTable.DATA = arrayOfRows;

		logger.log("supRepTable is " + supRepTable);
		returnJSONObj.Data = supRepTable;
		returnJSONObj.Status = "Success";
	} catch (e) {
		logger.log("Exception found " + e);
	}
	return returnJSONObj;
}

const getColumnName = async function (context, tip, surveyId) {
	logger.log("------  getColumnName(" + tip + ", " + surveyId + ")");
	var query = "", retval = "";
	try {
		query = "Select concat(lq.sid,'X',lq.gid,'X',lq.qid) as columnname "
			+ "from lime_questions lq Inner join lime_question_attributes lqa on lqa.qid=lq.qid and lqa.value='"
			+ tip + "' where lq.sid='"
			+ surveyId + "'";
		logger.log(query);

		// client.query(query, (err, result) => {
		// 	if (err) {
		// 		logger.log("Error executing query.", err);
		// 	}
		// 	else {
		// 		//logger.log('getColumnName results');
		// 		//logger.log (result.rows);
		// 		retval = result.rows[0].columnname;
		// 		return retval;
		// 	}
		// });
		const result = await client.query(query);
		retval = result.rows[0].columnname;
		logger.log(retval);
	}
	catch (e) {
		logger.log("Exception found " + e);
	}
	return retval;
}

const getActiveSurveyIds = async function (context) { // returns []
	logger.log("----------- getActiveSurveyIds()");

	var tableName = "";
	var s = [], arr = [], listOfSurveys = [];
	try {
		var query = "SELECT table_name FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE' AND table_name like 'lime_survey_%'";
		logger.log(query);

		// client.query (query, (err, result) => {
		// 	  if (err) logger.log("Error executing query.", err);
		//       else {
		//     	  result.rows.forEach (function myFunction(rowObj, index, array) {
		// 				tableName = rowObj.table_name;
		// 				s = tableName.split("_");
		// 				if (s.length == 3) {// &&  !s[2].replaceAll("^$"," ").matches("[^\\d\\.]")) // see if it has only two _ and last word is integer
		// 					listOfSurveys.push(s[2]);
		//     	  		}
		//     	  });
		//     	  //logger.log (listOfColumns);
		//     	  //return listOfSurveys;
		//     	  callback (context, listOfSurveys, arr);
		//       }
		// });

		const result = await client.query(query);
		logger.log("---- Done ..........");
		result.rows.forEach(function myFunction(rowObj, index, array) {
			tableName = rowObj.table_name;
			s = tableName.split("_");
			if (s.length == 3) {// &&  !s[2].replaceAll("^$"," ").matches("[^\\d\\.]")) // see if it has only two _ and last word is integer
				listOfSurveys.push(parseInt(s[2]));
			}
		});

		logger.log(arr);

	}
	catch (e) {
		logger.log("Exception found " + e);
	}
	return listOfSurveys;
}


var event = {
	queryStringParameters:
		{ surveyId: 814412, supplierId: 1, supplierName: 'Mallesh', surveyName: 'Sattva', sdate: '2018-11-02', edate: '2018-11-02' }
};
exports.handler(event);
